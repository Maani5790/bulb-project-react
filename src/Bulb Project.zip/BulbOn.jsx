import React from "react";
import bulbOn from "././assets/bulbon.jpg";
export default function BulbOn() {
  return (
    <div>
      <img src={bulbOn} alt='bulbon' width='350px' />
    </div>
  );
}